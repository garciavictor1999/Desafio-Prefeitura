<?php
require_once __DIR__ . "/../models/VerificacaoModel.php";

class VerificacaoController {
    private $model;

    public function __construct() {
        $this->model = new VerificacaoModel();
    }

    public function verificar($input) {
        if (empty($input)) {
            return "Entrada inválida.";
        }

        // Verificar se a porta está aberta
        $porta = 3306;
        if (!@fsockopen("localhost", $porta, $errno, $errstr, 2)) {
            return "Erro: Porta do banco de dados fechada.";
        }

        // Consultar no banco de dados
        $resultado = $this->model->verificarInputNoBanco($input);

        return $resultado ? $resultado : "Informação não encontrada.";
    }


	public function cadastrar() {
	    if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$cliente = [
		    'nome' => $_POST['nome'],
		    'cpf' => $_POST['cpf'],
		    'email' => $_POST['email']
		];

		$imovel = [
		    'endereco' => $_POST['endereco'],
		    'cidade' => $_POST['cidade'],
		    'cep' => $_POST['cep']
		];

		$model = new VerificacaoModel();
		$sucesso = $model->cadastrarClienteEImovel($cliente, $imovel);

		if ($sucesso) {
		    echo "Cadastro realizado com sucesso!";
		} else {
		    echo "Erro ao cadastrar.";
		}
	    }
	}
    }
?>
