<?php
require_once  "../config/database.php";

class VerificacaoModel {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->conectar();
    }

    public function verificarInputNoBanco($input) {
	if (ctype_digit($input) && strlen($input) === 11) {
		$query = "SELECT * FROM pessoas WHERE cpf = :input";
	} else {
		$query = "SELECT * FROM pessoas WHERE nome = :input";
	}
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":input", $input);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    public function cadastrarClienteEImovel($cliente, $imovel) {
        $conn = $this->db->getConnection();

        // Inserir cliente
        $queryCliente = "INSERT INTO clientes (nome, cpf, email) VALUES (:nome, :cpf, :email)";
        $stmt = $conn->prepare($queryCliente);
        $stmt->bindParam(":nome", $cliente['nome']);
        $stmt->bindParam(":cpf", $cliente['cpf']);
        $stmt->bindParam(":email", $cliente['email']);
        $stmt->execute();

        $clienteId = $conn->lastInsertId();

        // Inserir imóvel
        $queryImovel = "INSERT INTO imoveis (cliente_id, endereco, cidade, cep) VALUES (:cliente_id, :endereco, :cidade, :cep)";
        $stmt = $conn->prepare($queryImovel);
        $stmt->bindParam(":cliente_id", $clienteId);
        $stmt->bindParam(":endereco", $imovel['endereco']);
        $stmt->bindParam(":cidade", $imovel['cidade']);
        $stmt->bindParam(":cep", $imovel['cep']);
        return $stmt->execute();
    }
}


?>

