<?php
require_once "../controllers/VerificacaoController.php";
require_once "../config/database.php";
require_once "../models/VerificacaoModel.php";
require_once "../controllers/VerificacaoController.php";

$controller = new VerificacaoController();

$acao = $_GET['acao'] ?? 'form';

if ($acao === 'cadastrar') {
    $controller->cadastrar();
} else {
    include "../views/cadastro.php";
}


if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $input = $_POST["input"];

    // Verifica se é CPF (11 dígitos numéricos)
    $apenasNumeros = preg_replace('/\D/', '', $input);

    if (strlen($apenasNumeros) === 11 && ctype_digit($apenasNumeros)) {
        $inputTratado = $apenasNumeros; // é um CPF, envia sem pontuação
    } else {
        $inputTratado = trim($input); // é nome, envia como string
    }

    $controller = new VerificacaoController();
    $resultado = $controller->verificar($inputTratado); // chamada padrão
    require_once "../views/resultado.php";
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificação</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 40px;
        }
        form {
            max-width: 400px;
        }
        input, button {
            padding: 10px;
            font-size: 16px;
            margin-top: 10px;
            width: 100%;
            box-sizing: border-box;
        }
        label {
            font-weight: bold;
        }
    </style>
</head>
<body>
    <form method="POST" id="verificacaoForm">
        <label for="input">Digite um CPF ou nome:</label>
        <input type="text" name="input" id="input" required>
        <button type="submit">Verificar</button>
    </form>
</body>
</html>
