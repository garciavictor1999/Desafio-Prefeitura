<form method="POST" action="index.php?acao=cadastrar">
    <h3>Dados do Cliente</h3>
    Nome: <input type="text" name="nome"><br>
    CPF: <input type="text" name="cpf"><br>
    Email: <input type="email" name="email"><br>

    <h3>Dados do Imóvel</h3>
    Endereço: <input type="text" name="endereco"><br>
    Cidade: <input type="text" name="cidade"><br>
    CEP: <input type="text" name="cep"><br>

    <input type="submit" value="Cadastrar">
</form>

