<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Resultado</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #000;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h2>Resultado:</h2>

    <!-- Tabela para exibir os dados -->
    <table>
        <tr>
            <th>ID</th>
            <td><?php echo $resultado['id']; ?></td>
        </tr>
        <tr>
            <th>Nome</th>
            <td><?php echo $resultado['nome']; ?></td>
        </tr>
        <tr>
            <th>Data de Nascimento</th>
            <td><?php echo $resultado['data_nascimento']; ?></td>
        </tr>
        <tr>
            <th>CPF</th>
            <td><?php echo $resultado['cpf']; ?></td>
        </tr>
        <tr>
            <th>Sexo</th>
            <td><?php echo $resultado['sexo']; ?></td>
        </tr>
        <tr>
            <th>Telefone</th>
            <td><?php echo $resultado['telefone']; ?></td>
        </tr>
        <tr>
            <th>Email</th>
            <td><?php echo $resultado['email']; ?></td>
        </tr>
    </table>

    <a href="index.php">Voltar</a>
</body>
</html>
